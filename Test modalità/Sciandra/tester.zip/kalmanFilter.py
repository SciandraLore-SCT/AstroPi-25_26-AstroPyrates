# idea fare un filtro di kalman per python 3.11
# senza librerie infinite e per le foto e per il giroscopio 

import numpy as np

def kalman_filter_fusion(measurement_photo, measurement_gyro, 
                        state_estimate, state_variance,
                        process_variance=0.005, 
                        measurement_variance_photo=0.5,
                        measurement_variance_gyro=0.3):

    
    predicted_state = state_estimate 
    predicted_variance = state_variance + process_variance  
    
    measurements = []
    variances = []
    
    # Check which measurements are available
    if measurement_photo is not None:
        measurements.append(measurement_photo)
        variances.append(measurement_variance_photo)
    
    if measurement_gyro is not None:
        measurements.append(measurement_gyro)
        variances.append(measurement_variance_gyro)
    
    
    # Whit no measurements available, return prediction only
    if len(measurements) == 0:
        return predicted_state, predicted_variance
    
    
    # The Update - with at least one value

    if len(measurements) == 1:
        
        measurement = measurements[0]
        meas_variance = variances[0]
        # A single measurement to greatly simplify everything (the list is simply a single value)

        
        kalman_gain = predicted_variance / (predicted_variance + meas_variance)
        
        updated_state = predicted_state + kalman_gain * (measurement - predicted_state)        
        updated_variance = (1 - kalman_gain) * predicted_variance
    
    else:
        z = np.array(measurements)
        R = np.diag(variances)  
        
        H = np.ones((len(measurements), 1))
        y = z - (H @ np.array([[predicted_state]])).flatten()
        S = H @ np.array([[predicted_variance]]) @ H.T + R
        
        K = (np.array([[predicted_variance]]) @ H.T @ np.linalg.inv(S)).flatten()
        
        updated_state = predicted_state + K @ y
        
        updated_variance = predicted_variance - K @ H * predicted_variance
        
        updated_state = float(updated_state)
        updated_variance = float(updated_variance)
    
    
    return updated_state, updated_variance


# Example of how to use it in your ISSSpeedCalculator class:
"""
In __init__:
    self.kalman_state = 7.66  # initial guess (known ISS velocity)
    self.kalman_variance = 1.0  # initial uncertainty

In esegui() loop, replace the validation section with:

    vel_foto = self.calcola_velocita_foto(...) if len(self.foto_lista) >= 2 else None
    vel_ang = self.calcola_velocita_angolare()
    
    # Apply Kalman filter
    self.kalman_state, self.kalman_variance = kalman_filter_fusion(
        measurement_photo=vel_foto,
        measurement_gyro=vel_ang,
        state_estimate=self.kalman_state,
        state_variance=self.kalman_variance,
        process_variance=0.001,  # tune this
        measurement_variance_photo=0.5,  # tune this
        measurement_variance_gyro=0.2   # tune this
    )
    
    self.velocita_filtrate.append(self.kalman_state)
    self.scrivi_risultati(f"FILTERED: {self.kalman_state:.4f} km/s")
"""